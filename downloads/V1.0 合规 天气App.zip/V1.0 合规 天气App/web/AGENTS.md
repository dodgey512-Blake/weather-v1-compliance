<!-- BEGIN:nextjs-agent-rules -->

## This is NOT the Next.js you know

This version has breaking changes — APIs, conventions, and file structure may all differ from your training data. Read the relevant guide in `node_modules/next/dist/docs/` (resolved from this file's directory; in monorepos the `next` package may not be visible from the repo root) before writing any code. Heed deprecation notices.

This block is written and re-added by `next dev` — verify at `node_modules/next/dist/server/lib/generate-agent-files.js`. Removing it from a diff only re-creates the uncommitted change; committing it with your work keeps the tree clean.

<!-- END:nextjs-agent-rules -->

## Weather 项目

1. 当前需求以docs/product-requirements-compliance.md为准，完整交付状态见../release.json与../artifacts/。
2. 默认简体中文，英文/单位/计划时区独立。独立公开basePath为/weather-v1-compliance/。
3. 原站archive与原版源码由父项目保留，本副本仅导出新站，不写旧站根目录。
4. 数据规则app/core.ts与services.ts，实际时效展示选择在model.ts的displayHour。失效观测不能用于首页或OOTD。
5. NWS-only、4预置城市、AQI缺失不应用改期，定位前披露与近似坐标、通知真实状态、默认脱敏导出和旧版隔离必须保留。
6. release:site只写本版out，prepare-export添加静态CSP。修改运行文件后重新build再同步Android，不能仅改网页而保留旧APK。

最终发布还需从合规项目根执行`node scripts/prepare-export.mjs`。VIS仅允许同源SVG文档嵌入，主App仍frame-src none；幂等性与最终导出CSP以`artifacts/vis-csp-fix.json`为依据，不用dev组件库验收替代。
