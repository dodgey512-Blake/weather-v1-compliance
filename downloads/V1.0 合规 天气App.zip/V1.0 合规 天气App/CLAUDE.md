# V1.0 合规 天气App

2026年11月7日授权的独立天气合规副本，来源为天气App融资BP最新V1.0。原demo/V1.0-双语天气MVP、Android/WeatherV1、旧VIS与交付保留。

## 主事实源

1. 本版Web为web/，Android为android/，页面导出为web/out/，设计为web/public/vis-2/，发布副本为publish-checkout/site/，安装包及完整ZIP为dist/。
2. 产品文档V1.0 合规 天气App.md，审查记录合规审查与修复记录.md，最终链接和实际测试结果读取release.json与artifacts/。
3. 只向独立weather-v1-compliance仓库发布，避免原网站的构建流程重写旧公开资源。原版277项基线记录于artifacts/original-hashes.json，父项目上下文只按授权追加。

## 产品约束

1. NWS-only为当前真实数据模式。Open-Meteo免费API商用资格未确认，地点搜索与AQI免费端默认停用，地名从既有4个城市本地匹配。主动GPS先披露，再近似到0.01度，仍属于位置数据。
2. AQI缺失、过期、未来发布时刻、失效警报和不完整训练时段均如实处理。未知不能假0、旧缓存不能伪装新数据，不能应用数据不足的改期。
3. 无自有登录，Web主存储/draft/session/SW独立。JSON默认脱敏，通知可关闭，本版清除同时取消原生通知与状态，不动旧数据。
4. 报价是自愿意向，无真实商店订阅或广告。天气/穿衣/跑步建议不作医学、救援或安全保证。Google Health声明需按实际训练记录功能核对。
5. 默认简体中文，设置切英文，语言、单位和计划时区独立。VIS沿用天气主产品的深蓝、暖白、少量绿及Lucide，补充合规状态板。
6. Next等依赖按现行公告定点更新，生产依赖audit复核。静态导出并未运行所述服务端API，不将公告范围等同已发生攻击。

## 交付

1. 飞书本人UAT创建并核验归属，6张实际截图按段内嵌，完整回读、公开权限与匿名读者访问验收。
2. Android独立包com.weatherpersonal.app.compliance，可与原版并装，测试签名及模拟器范围如实报告。历史SystemUI ANR不能用旧验收结论掩盖，重测后记录。
3. 发布前核对完整ZIP无凭证/构建缓存/SDK镜像，所有公开文件匿名HTTP/SHA、关键操作与旧版保护结果均记录。
4. 正式发行门槛包括商业数据方案与后端标识/监控、法定公司与客服/隐私联系人、国家/年龄/Health及商店表单、真实IAP/广告、iOS原生、真机及读屏、正式签名/审批。

## 最终导出验收补充

W10生产冒烟发现VIS的同源object文档被统一frame-src none拦截，已只对VIS页面允许self，主App与原生响应保持none。prepare-export必须在最终导出后验证且保持幂等；普通dev组件库检查不能替代部署策略验收。证据为vis-csp-fix.json及最终deployed-browser.json。Android现有VIS入口外开公网，不能写成内部桥已允许嵌入。最终APK/工程/完整ZIP全部按修复后文件重打并校验。
