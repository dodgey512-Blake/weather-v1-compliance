#!/bin/sh
set -eu
WEATHER_ANDROID_ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$WEATHER_ANDROID_ROOT"
if [ -z "${ANDROID_HOME:-}" ] && [ -d "$HOME/Library/Android/sdk" ]; then
  ANDROID_HOME="$HOME/Library/Android/sdk"
  export ANDROID_HOME
fi
if [ "$#" -gt 0 ]; then
  node scripts/package-web.mjs "$1"
elif [ -f ../web/out/index.html ]; then
  node scripts/package-web.mjs ../web/out
fi
./gradlew :app:assembleDebug :app:assembleDebugAndroidTest :app:lintDebug --console=plain
python3 scripts/verify-apk-assets.py
mkdir -p ../dist acceptance
cp app/build/outputs/apk/debug/app-debug.apk '../dist/V1.0 合规 天气App.apk'
cp app/build/outputs/apk/androidTest/debug/app-debug-androidTest.apk acceptance/tests.apk
python3 scripts/archive-source.py
shasum -a 256 '../dist/V1.0 合规 天气App.apk' '../dist/V1.0 合规 天气App-AndroidStudio.zip' > ../dist/SHA256SUMS.txt
