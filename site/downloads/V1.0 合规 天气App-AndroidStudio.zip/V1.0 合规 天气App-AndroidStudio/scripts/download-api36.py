"""Resume the official, checksummed test image with independent HTTP byte ranges."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib
import math
import os
import shutil
import time
import urllib.request

root = Path(__file__).resolve().parents[1] / '.runtime-sdk'
root.mkdir(exist_ok=True)
target = root / 'android36.zip'
prefix = root / 'android36.prefix'
url = 'https://dl.google.com/android/repository/sys-img/google_apis/arm64-v8a-36_r07.zip'
size = 1872691175
checksum = '5a99183b6d924da606260e45fd41a3eb8eca6eb7'
if not prefix.exists() and target.exists():
    target.rename(prefix)
start = prefix.stat().st_size if prefix.exists() else 0
if start > size:
    raise SystemExit('Unexpected prefix size')
step = math.ceil((size - start) / 6) if start < size else 0
ranges = [(pos, min(size-1, pos+step-1)) for pos in range(start, size, step)] if step else []

def get(item):
    first, last = item
    part = root / f'part-{first:012d}'
    expected = last-first+1
    if part.exists() and part.stat().st_size == expected:
        return part
    for attempt in range(3):
        try:
            request = urllib.request.Request(url, headers={'Range': f'bytes={first}-{last}'})
            with urllib.request.urlopen(request, timeout=45) as response:
                if response.status != 206 or response.headers.get('Content-Range') != f'bytes {first}-{last}/{size}':
                    raise RuntimeError('Server did not honor the requested byte range')
                with part.open('wb') as output:
                    shutil.copyfileobj(response, output, 1024*1024)
            if part.stat().st_size != expected:
                raise RuntimeError('Incomplete byte range')
            print(f'Downloaded range {first}-{last}', flush=True)
            return part
        except Exception:
            if attempt == 2:
                raise
            time.sleep(2)

print(f'Official API36 image: preserving {start} prefix bytes, fetching {len(ranges)} ranges', flush=True)
with ThreadPoolExecutor(max_workers=6) as pool:
    parts = list(pool.map(get, ranges))
with target.open('wb') as output:
    if prefix.exists():
        with prefix.open('rb') as source:
            shutil.copyfileobj(source, output)
    for part in parts:
        with part.open('rb') as source:
            shutil.copyfileobj(source, output)
digest = hashlib.sha1()
with target.open('rb') as source:
    while chunk := source.read(1024*1024):
        digest.update(chunk)
if target.stat().st_size != size or digest.hexdigest() != checksum:
    raise SystemExit('Official image checksum mismatch; parts retained for diagnosis')
print('Official API36 image size and SHA-1 verified', flush=True)
for part in parts:
    part.unlink()
if prefix.exists():
    prefix.unlink()
