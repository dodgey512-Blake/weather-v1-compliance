import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

/** Resolve the operator's SDK at runtime. No workstation path is shipped. */
export function adbPath() {
  const executable = process.platform === 'win32' ? 'adb.exe' : 'adb';
  const roots = [process.env.ANDROID_HOME, process.env.ANDROID_SDK_ROOT,
    path.join(os.homedir(), 'Library', 'Android', 'sdk'),
    path.join(os.homedir(), 'Android', 'Sdk'),
    process.env.LOCALAPPDATA && path.join(process.env.LOCALAPPDATA, 'Android', 'Sdk')];
  const installed = roots.filter(Boolean).map(root => path.join(root, 'platform-tools', executable)).find(file => fs.existsSync(file));
  return installed || executable;
}
