import fs from 'node:fs/promises';
import { adbPath } from './android-tools.mjs';
import {execFileSync} from 'node:child_process';
const adb=adbPath();
const command=(...args)=>execFileSync(adb,['-s','emulator-5556',...args],{encoding:'utf8'}).trim();
const pid=command('shell','pidof','com.weatherpersonal.app.compliance');if(!/^\d+$/.test(pid))throw Error('New app process is unavailable');
const port=command('forward','tcp:0','localabstract:webview_devtools_remote_'+pid);if(!/^\d+$/.test(port))throw Error('Debug forward did not return a port');
const targets=await(await fetch('http://127.0.0.1:'+port+'/json/list')).json(),target=targets.find(t=>t.url.startsWith('https://appassets.androidplatform.net/weather-v1-compliance/'));
if(!target)throw Error('Final edition WebView target missing');
const socket=new WebSocket(target.webSocketDebuggerUrl),pending=new Map();let id=0;
await new Promise((resolve,reject)=>{socket.addEventListener('open',resolve,{once:true});socket.addEventListener('error',reject,{once:true});});
socket.addEventListener('message',e=>{const m=JSON.parse(e.data),p=pending.get(m.id);if(p){pending.delete(m.id);clearTimeout(p.timer);m.error?p.reject(Error(m.error.message)):p.resolve(m.result);}});
const call=(method,params={})=>new Promise((resolve,reject)=>{const n=++id;const timer=setTimeout(()=>{pending.delete(n);reject(Error(method+' timed out'));},15000);pending.set(n,{resolve,reject,timer});socket.send(JSON.stringify({id:n,method,params}));});
const evaluate=async expression=>{const r=await call('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});if(r.exceptionDetails)throw Error(JSON.stringify(r.exceptionDetails));return r.result.value;};
const pause=ms=>new Promise(resolve=>setTimeout(resolve,ms));
const checks=[];const check=(name,value)=>{if(!value)throw Error(name);checks.push(name);};
let saved;
try {
 const readyBy=Date.now()+20000;while(Date.now()<readyBy && !(await evaluate("!!window.WeatherNative && document.querySelectorAll('button').length>0")))await pause(100);
 check('final bundled application starts',await evaluate("!!window.WeatherNative && document.querySelectorAll('button').length>0 && location.pathname==='/weather-v1-compliance/'"));
 saved=await evaluate("localStorage.getItem('weather-personal-v1-compliance')");
 await call('Network.enable');await call('Network.setBlockedURLs',{urls:['*api.weather.gov*']});
 // A controlled old observation plus current-hour forecast catches use of stale current data.
 await evaluate(`(()=>{const key='weather-personal-v1-compliance',now=Date.now(),hour=3600000,base=JSON.parse(localStorage.getItem(key));if(!base)throw Error('Existing isolated test state missing');const h={startAt:now-60000,endAt:now+hour,tempC:11,feelsC:11,pop:0,windKmh:5,gustKmh:5,humidity:50,condition:'clear',isDay:true};const snap={id:'native-ui-fixture',location:base.location,mode:'live',fetchedAt:now,issuedAt:now-60000,observedAt:now-4*hour,expiresAt:now+hour,status:'partial',current:{...h,startAt:now-4*hour,endAt:now-3*hour,tempC:39,feelsC:39},hours:[h],alerts:[],alertsStatus:'live',aqi:null,sources:[{id:'forecast',name:'NWS hourly forecast',status:'live',issuedAt:now-60000,fetchedAt:now,expiresAt:now+hour,url:'https://www.weather.gov/'},{id:'observation',name:'NWS observation',status:'stale',issuedAt:now-4*hour,fetchedAt:now,expiresAt:now-2*hour,url:'https://www.weather.gov/'},{id:'alerts',name:'NWS alerts',status:'live',issuedAt:now,fetchedAt:now,expiresAt:now+300000,url:'https://www.weather.gov/'}],issues:[]};localStorage.setItem(key,JSON.stringify({...base,onboarded:true,language:'zh-CN',units:'metric',monitoring:false,notifications:false,snapshots:{[base.location.id]:snap}}));location.hash='#/today';location.reload();return true})()`);
 await pause(1800);
 const zh=await evaluate("({temperature:document.querySelector('.temperature')?.textContent,text:document.body.innerText,lang:document.documentElement.lang})");
 check('stale observation cannot replace the current forecast temperature',zh.temperature?.includes('11')&&!zh.temperature?.includes('39'));
 check('forecast fallback is explicitly labeled in Chinese',zh.text.includes('当前时段预报')&&zh.text.includes('当前观测已过期'));
 await evaluate("location.hash='#/outfit'");await pause(350);
 const outfit=await evaluate('document.body.innerText');check('OOTD uses the fresh forecast layer recommendation',outfit.includes('轻内层 + 可脱卸外套')&&!outfit.includes('轻薄透气的一层'));
 await evaluate("location.hash='#/settings'");await pause(300);
 await evaluate("(()=>{const b=[...document.querySelectorAll('button')].find(b=>b.innerText.trim()==='English');if(!b)throw Error('English button missing');b.click();return true})()");await pause(350);
 check('final WebView switches to English',await evaluate("document.documentElement.lang==='en' && document.body.innerText.includes('Settings')"));
 await evaluate("location.hash='#/today'");await pause(300);
 const en=await evaluate("({temperature:document.querySelector('.temperature')?.textContent,text:document.body.innerText})");
 check('English forecast fallback preserves the 11 degree value',en.temperature?.includes('11')&&en.text.includes('Current-hour forecast'));
 await evaluate("location.hash='#/settings'");await pause(250);
 await evaluate("(()=>{[...document.querySelectorAll('button')].find(b=>b.innerText.trim()==='简体中文').click();return true})()");await pause(300);
 check('final WebView returns to Chinese',await evaluate("document.documentElement.lang.startsWith('zh') && document.body.innerText.includes('设置')"));
 await fs.writeFile('acceptance/final-ui.json',JSON.stringify({passed:checks.length,checks,fixture:'Controlled stale-observation/current-hour-forecast snapshot in the isolated emulator only',scope:'Final repackaged APK UI; preserved host-native tests recorded separately'},null,2));console.log(JSON.stringify({passed:checks.length,checks}));
} finally {
 if(saved!==undefined){await evaluate(`localStorage.setItem('weather-personal-v1-compliance',${JSON.stringify(saved)});location.hash='#/settings';location.reload()`);}
 await call('Network.setBlockedURLs',{urls:[]}).catch(()=>{});socket.close();command('forward','--remove','tcp:'+port);
}
