#!/bin/sh
set -eu
WEATHER_SDK="${ANDROID_HOME:-$HOME/Library/Android/sdk}"
# API 37 requires GLES 3.1. SwiftShader avoids macOS host-GLES 3.0 hangs.
exec "$WEATHER_SDK/emulator/emulator" -avd "${1:-Medium_Phone_API_37.0}" -no-snapshot-load -no-snapshot-save -gpu swiftshader -no-audio -cores 2
