import fs from 'node:fs/promises';
import { execFileSync } from 'node:child_process';
import { adbPath } from './android-tools.mjs';
const adb = (...args) => execFileSync(adbPath(), ['-s', 'emulator-5556', ...args], { encoding: 'utf8' }).trim();
const pid = adb('shell', 'pidof', 'com.weatherpersonal.app.compliance');
if (!/^\d+$/.test(pid)) throw Error('New app process missing');
const port = adb('forward', 'tcp:0', 'localabstract:webview_devtools_remote_' + pid);
const targets = await (await fetch('http://127.0.0.1:' + port + '/json/list')).json();
const target = targets.find(item => item.url.startsWith('https://appassets.androidplatform.net/weather-v1-compliance/'));
if (!target) throw Error('New bundled WebView unavailable');
const socket = new WebSocket(target.webSocketDebuggerUrl), pending = new Map(); let id = 0;
await new Promise((resolve, reject) => { socket.addEventListener('open', resolve, { once: true }); socket.addEventListener('error', reject, { once: true }); });
socket.addEventListener('message', event => { const message = JSON.parse(event.data), item = pending.get(message.id); if (item) { pending.delete(message.id); clearTimeout(item.timer); message.error ? item.reject(Error(message.error.message)) : item.resolve(message.result); } });
const call = (method, params = {}) => new Promise((resolve, reject) => { const key = ++id, timer = setTimeout(() => { pending.delete(key); reject(Error(method + ' timeout')); }, 15000); pending.set(key, { resolve, reject, timer }); socket.send(JSON.stringify({ id: key, method, params })); });
const evaluate = async expression => { const result = await call('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true }); if (result.exceptionDetails) throw Error(JSON.stringify(result.exceptionDetails)); return result.result.value; };
const pause = ms => new Promise(resolve => setTimeout(resolve, ms));
const checks = [], expected = 'https://dodgey512-blake.github.io/weather-v1-compliance/vis-2/';
const check = (name, value) => { if (!value) throw Error(name); checks.push(name); };
try {
  const limit = Date.now() + 20000;
  while (Date.now() < limit && !(await evaluate("!!window.WeatherNative && document.querySelectorAll('button').length>0"))) await pause(100);
  check('final APK starts with its native facade', await evaluate("!!window.WeatherNative && document.querySelectorAll('button').length>0"));
  const policy = await evaluate("fetch('/weather-v1-compliance/vis-2/index.html').then(async response=>{const header=response.headers.get('content-security-policy'),html=await response.text(),doc=new DOMParser().parseFromString(html,'text/html');return {header,meta:doc.querySelector('meta[http-equiv=\"Content-Security-Policy\"]')?.content,hasFavicon:!!doc.querySelector('link[rel=\"icon\"]')}})");
  check('bundled VIS meta permits same-origin SVG frames', policy.meta.includes("frame-src 'self'") && policy.meta.includes("object-src 'self'"));
  check('bundled VIS references the existing favicon', policy.hasFavicon);
  check('native response keeps embedded document boundaries closed', policy.header.includes("frame-src 'none'") && policy.header.includes("object-src 'none'"));
  await evaluate("location.hash='#/settings'"); await pause(500);
  check('settings uses the separate VIS route', await evaluate("!!document.querySelector('a[href=\"/weather-v1-compliance/vis-2/\"]')"));
  await evaluate("document.querySelector('a[href=\"/weather-v1-compliance/vis-2/\"]').click()"); await pause(1000);
  const activities = adb('shell', 'dumpsys', 'activity', 'activities');
  check('VIS entry launches an external browser', activities.includes('com.android.chrome')); 
  check('the app WebView retains its bundled origin after handoff', await evaluate("location.origin==='https://appassets.androidplatform.net' && location.pathname==='/weather-v1-compliance/'"));
  const report = { passed: checks.length, checks, expectedExternalUrl: expected, localVisEmbeddedSupported: false, localVisPolicy: 'Native response continues object-src none/frame-src none. The product entry opens the public VIS externally.', scope: 'Final APK startup, exact bundled VIS resource and actual Android ACTION_VIEW target. Public SVG rendering is verified separately.' };
  await fs.writeFile('acceptance/final-vis-link.json', JSON.stringify(report, null, 2)); console.log(JSON.stringify({ passed: checks.length, expectedExternalUrl: expected }));
} finally {
  socket.close(); adb('forward', '--remove', 'tcp:' + port);
  adb('shell', 'am', 'start', '-W', '-n', 'com.weatherpersonal.app.compliance/com.weatherpersonal.app.MainActivity');
}
