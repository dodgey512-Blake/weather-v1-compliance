// Operation checks against the running isolated emulator. Does not modify the APK.
import fs from 'node:fs/promises';
import { adbPath } from './android-tools.mjs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {execFileSync} from 'node:child_process';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const adbArgs=['-s','emulator-5556'];
const adb=(...args)=>execFileSync(adbPath(),[...adbArgs,...args],{encoding:'utf8',timeout:30000});
const targets=await (await fetch('http://127.0.0.1:9223/json/list')).json();const target=targets.find(t=>t.url.startsWith('https://appassets.androidplatform.net/weather-v1-compliance/'));
const ws=new WebSocket(target.webSocketDebuggerUrl);const pending=new Map();let id=0;
await new Promise((resolve,reject)=>{ws.addEventListener('open',resolve,{once:true});ws.addEventListener('error',reject,{once:true});});
ws.addEventListener('message',e=>{const message=JSON.parse(e.data);const item=pending.get(message.id);if(item){pending.delete(message.id);clearTimeout(item.timer);message.error?item.reject(Error(message.error.message)):item.resolve(message.result);}});
const call=(method,params={})=>new Promise((resolve,reject)=>{const n=++id;const timer=setTimeout(()=>reject(Error(method+' timed out')),30000);pending.set(n,{resolve,reject,timer});ws.send(JSON.stringify({id:n,method,params}));});
const evaluate=async expression=>{const x=await call('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});if(x.exceptionDetails)throw Error(JSON.stringify(x.exceptionDetails));return x.result.value;};
const pause=ms=>new Promise(resolve=>setTimeout(resolve,ms));
const click=label=>evaluate(`(()=>{const b=[...document.querySelectorAll('button')].find(e=>e.innerText.includes(${JSON.stringify(label)}));if(!b)throw Error('Missing '+${JSON.stringify(label)});b.click();return true})()`);
const report={api:36,checkedAt:new Date().toISOString(),source:'Actual Android WebView and native system UI'};
try{
  await evaluate("window.__nativeEvents=[];window.addEventListener('weather-native',e=>window.__nativeEvents.push(e.detail))");
  if(!(await evaluate('location.hash')).includes('/settings'))await click('设置');
  await click('数据来源与判断规则');await pause(500);report.beforeBack=await evaluate('location.hash');
  adb('shell','input','keyevent','4');await pause(800);report.afterBack=await evaluate('location.hash');report.nativeBack=report.afterBack!==report.beforeBack;
  console.log(JSON.stringify({nativeBack:report.nativeBack,before:report.beforeBack,after:report.afterBack}));
  if(!(await evaluate('location.hash')).includes('/settings'))await click('设置');
  await click('导出计划与实验记录');await pause(1000);
  adb('shell','uiautomator','dump','--compressed','/sdcard/weather-window.xml');
  const xml=adb('shell','cat','/sdcard/weather-window.xml');await fs.writeFile(path.join(root,'acceptance','native-save-window.xml'),xml);
  console.log('SAVE_UI',xml.slice(0,5000));
  report.events=await evaluate('window.__nativeEvents');
}catch(error){report.error=error.message;console.log(JSON.stringify({error:error.message}));}
finally{await fs.writeFile(path.join(root,'acceptance','native-operation-check.json'),JSON.stringify(report,null,2));ws.close();}
