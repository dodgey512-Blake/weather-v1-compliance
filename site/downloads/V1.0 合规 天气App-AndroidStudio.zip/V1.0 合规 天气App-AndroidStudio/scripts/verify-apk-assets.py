from pathlib import Path
from zipfile import ZipFile
import hashlib
import json

root = Path(__file__).resolve().parents[1]
assets = root / 'app/src/main/assets/weather-v1-compliance'
apk = root / 'app/build/outputs/apk/debug/app-debug.apk'
files = [p for p in assets.rglob('*') if p.is_file()]
next_files = [p for p in files if '_next' in p.relative_to(assets).parts]
if not next_files:
    raise SystemExit('Web runtime is missing from the source bundle')
with ZipFile(apk) as archive:
    names = set(archive.namelist())
    for file in [p for p in files if not any(part.startswith('.') for part in p.relative_to(assets).parts)]:
        entry = 'assets/weather-v1-compliance/' + file.relative_to(assets).as_posix()
        if entry not in names or archive.read(entry) != file.read_bytes():
            raise SystemExit(f'APK asset missing or outdated: {entry}')
    manifest = json.loads((root / 'web-bundle.json').read_text())
    digest = hashlib.sha256(archive.read('assets/weather-v1-compliance/index.html')).hexdigest()
    if digest != manifest['entrySha256']:
        raise SystemExit('APK entry does not match the recorded Web bundle')
print(json.dumps({'apkAssetCheck': True, 'verifiedNextFiles': len(next_files), 'verifiedAssetFiles': len([p for p in files if not any(part.startswith('.') for part in p.relative_to(assets).parts)]), 'entrySha256': digest}))
