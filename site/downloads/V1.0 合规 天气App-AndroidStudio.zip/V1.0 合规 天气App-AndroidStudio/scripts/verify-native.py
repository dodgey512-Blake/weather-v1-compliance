"""Install and smoke-test this app on an already running Android emulator."""
from pathlib import Path
import argparse
import json
import os
import re
import shutil
import subprocess
import time
from datetime import datetime, timezone

root = Path(__file__).resolve().parents[1]
args = argparse.ArgumentParser()
args.add_argument('--serial', default='emulator-5556')
args.add_argument('--fresh', action='store_true', help='Clear only com.weatherpersonal.app.compliance test data before checking Chinese defaults')
options = args.parse_args()
sdk = Path(os.environ.get('ANDROID_HOME', str(Path.home() / 'Library/Android/sdk')))
adb = shutil.which('adb') or str(sdk / 'platform-tools/adb')
evidence = root / 'acceptance'
evidence.mkdir(exist_ok=True)

def call(*parts, binary=False):
    return subprocess.check_output([adb, '-s', options.serial, *parts], timeout=90, text=not binary)

for file in [root / 'app/build/outputs/apk/debug/app-debug.apk', root / 'app/build/outputs/apk/androidTest/debug/app-debug-androidTest.apk']:
    print(call('install', '--no-streaming', '-r', str(file)).strip(), flush=True)
if options.fresh:
    print(call('shell', 'pm', 'clear', 'com.weatherpersonal.app.compliance').strip())
instrumentation = subprocess.check_output([adb, '-s', options.serial, 'shell', 'am', 'instrument', '-w', '-r', 'com.weatherpersonal.app.compliance.test/com.weatherpersonal.app.SmokeInstrumentation'], timeout=180, text=True)
(evidence / 'instrumentation.txt').write_text(instrumentation)
print(instrumentation)
success = 'INSTRUMENTATION_CODE: -1' in instrumentation and 'FAIL ' not in instrumentation
count = re.search(r'INSTRUMENTATION_RESULT: checks=(\d+)', instrumentation)
call('shell', 'am', 'start', '-W', '-n', 'com.weatherpersonal.app.compliance/com.weatherpersonal.app.MainActivity')
time.sleep(2)
(evidence / 'native-screen.png').write_bytes(call('exec-out', 'screencap', '-p', binary=True))
result = {
    'checkedAt': datetime.now(timezone.utc).isoformat(),
    'deviceType': 'Android emulator',
    'serial': options.serial,
    'api': call('shell', 'getprop', 'ro.build.version.sdk').strip(),
    'passed': success,
    'checks': int(count.group(1)) if count else 0,
    'physicalDeviceVerified': False,
    'sourceOfUI': 'packaged WebViewAssetLoader assets',
    'backgroundWeatherMonitoringImplemented': False,
}
(evidence / 'native-acceptance.json').write_text(json.dumps(result, ensure_ascii=False, indent=2))
if not success:
    raise SystemExit('Android smoke did not pass; inspect acceptance/instrumentation.txt')
