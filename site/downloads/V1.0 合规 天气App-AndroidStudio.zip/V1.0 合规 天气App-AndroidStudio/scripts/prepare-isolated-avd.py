"""Prepare the task-local API 36 emulator, after downloading the official image archive."""
from pathlib import Path
import hashlib
import zipfile

root = Path(__file__).resolve().parents[1]
sdk = root / '.runtime-sdk'
archive = sdk / 'android36.zip'
expected = '5a99183b6d924da606260e45fd41a3eb8eca6eb7'
digest = hashlib.sha1()
with archive.open('rb') as stream:
    while chunk := stream.read(1024 * 1024):
        digest.update(chunk)
if digest.hexdigest() != expected:
    raise SystemExit('Official API 36 system-image SHA-1 does not match')
image = sdk / 'image'
with zipfile.ZipFile(archive) as source:
    for entry in source.namelist():
        if Path(entry).is_absolute() or '..' in Path(entry).parts:
            raise SystemExit('Unsafe archive path')
    source.extractall(image)
sysdir = next(image.rglob('source.properties')).parent
avd_root = root / '.runtime-avd'
avd = avd_root / 'WeatherV1_API36.avd'
avd.mkdir(parents=True, exist_ok=True)
(avd_root / 'WeatherV1_API36.ini').write_text(f'avd.ini.encoding=UTF-8\npath={avd}\ntarget=android-36\n')
config = {
    'AvdId':'WeatherV1_API36','avd.ini.displayname':'Weather V1 API 36','avd.ini.encoding':'UTF-8',
    'abi.type':'arm64-v8a','hw.cpu.arch':'arm64','hw.cpu.ncore':'4','hw.ramSize':'2048',
    'hw.gpu.enabled':'yes','hw.gpu.mode':'swiftshader','hw.lcd.width':'540','hw.lcd.height':'1200','hw.lcd.density':'210',
    'hw.keyboard':'yes','hw.mainKeys':'no','hw.gps':'yes','hw.accelerometer':'yes','hw.battery':'yes',
    'hw.initialOrientation':'portrait','disk.dataPartition.size':'6G','fastboot.forceColdBoot':'yes',
    'fastboot.forceFastBoot':'no','image.sysdir.1':str(sysdir)+'/', 'tag.id':'google_apis','tag.display':'Google APIs',
    'target':'android-36','PlayStore.enabled':'false','vm.heapSize':'256','showDeviceFrame':'no',
}
(avd / 'config.ini').write_text(''.join(f'{key}={value}\n' for key,value in config.items()))
print(f'Isolated AVD ready: {avd}')
