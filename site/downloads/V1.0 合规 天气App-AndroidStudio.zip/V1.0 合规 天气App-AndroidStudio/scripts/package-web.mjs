import { cp, mkdir, readFile, writeFile, access, rm } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import crypto from 'node:crypto';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const source=path.resolve(process.argv[2]||path.join(root,'../web/out'));
const destination=path.join(root,'app/src/main/assets/weather-v1-compliance');
await access(path.join(source,'index.html'));
const html=await readFile(path.join(source,'index.html'),'utf8');
if(!html.includes('/weather-v1-compliance/_next/'))throw new Error('Web export must use basePath /weather-v1-compliance; refusing an incompatible package.');
await rm(destination,{recursive:true,force:true});
await mkdir(destination,{recursive:true});
// Installation archives are delivery artifacts, not recursively bundled application assets.
await cp(source,destination,{recursive:true,force:true,filter:file=>!path.relative(source,file).split(path.sep).includes('downloads')});
const manifest={webVersion:'1.0.0-compliance',basePath:'/weather-v1-compliance/',copiedAt:new Date().toISOString(),entrySha256:crypto.createHash('sha256').update(html).digest('hex')};
await writeFile(path.join(root,'web-bundle.json'),JSON.stringify(manifest,null,2));
console.log(JSON.stringify({packaged:true,...manifest}));
