from pathlib import Path
import zipfile

root = Path(__file__).resolve().parents[1]
output = root.parent / 'dist' / 'V1.0 合规 天气App-AndroidStudio.zip'
output.parent.mkdir(parents=True, exist_ok=True)
excluded = {'.gradle', '.idea', 'build', 'dist', '.runtime-sdk', '.runtime-avd', 'acceptance'}
with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED) as archive:
    for item in sorted(root.rglob('*')):
        rel = item.relative_to(root)
        if not item.is_file() or any(part in excluded for part in rel.parts):
            continue
        if item.name in {'local.properties', '.DS_Store'} or item.suffix == '.log':
            continue
        archive.write(item, Path('V1.0 合规 天气App-AndroidStudio') / rel)
with zipfile.ZipFile(output) as archive:
    if archive.testzip() is not None:
        raise RuntimeError('Archive verification failed')
    count = len(archive.namelist())
print(f'Android Studio source archive: {count} files')
