import fs from 'node:fs/promises';
import { adbPath } from './android-tools.mjs';
import {execFileSync} from 'node:child_process';
const targets=await(await fetch('http://127.0.0.1:9224/json/list')).json();
const target=targets.find(t=>t.url.startsWith('https://appassets.androidplatform.net/weather-v1-compliance/'));
if(!target)throw Error('New edition WebView is unavailable');
const socket=new WebSocket(target.webSocketDebuggerUrl),pending=new Map();let id=0;
await new Promise((resolve,reject)=>{socket.addEventListener('open',resolve,{once:true});socket.addEventListener('error',reject,{once:true});});
socket.addEventListener('message',e=>{const m=JSON.parse(e.data),p=pending.get(m.id);if(p){pending.delete(m.id);clearTimeout(p.timer);m.error?p.reject(Error(m.error.message)):p.resolve(m.result);}});
const call=(method,params={})=>new Promise((resolve,reject)=>{const key=++id;const timer=setTimeout(()=>reject(Error(method+' timed out')),15000);pending.set(key,{resolve,reject,timer});socket.send(JSON.stringify({id:key,method,params}));});
const evaluate=async expression=>{const result=await call('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});if(result.exceptionDetails)throw Error(JSON.stringify(result.exceptionDetails));return result.result.value;};
const pause=ms=>new Promise(r=>setTimeout(r,ms));
const click=label=>evaluate(`(()=>{const b=[...document.querySelectorAll('button')].find(e=>e.innerText.trim()===${JSON.stringify(label)});if(!b)throw Error('Missing button '+${JSON.stringify(label)});b.click();return true})()`);
const passed=[];
try {
 const text=await evaluate('document.body.innerText');
 if(text.includes('先看看 Austin 的天气气'))await click('先看看 Austin 的天气气');
 else if(text.includes('先看看 Austin 的天气'))await click('先看看 Austin 的天气');
 await pause(1000);await click('设置');await pause(500);
 const original=await evaluate("(()=>{const s=JSON.parse(localStorage.getItem('weather-personal-v1-compliance'));return {language:s.language,units:s.units,location:s.location,plans:s.plans}})()");
 await click('English');await pause(500);
 const english=await evaluate("(()=>{const s=JSON.parse(localStorage.getItem('weather-personal-v1-compliance'));return {language:s.language,units:s.units,location:s.location,plans:s.plans,title:document.body.innerText}})()");
 if(english.language!=='en'||!english.title.includes('Settings'))throw Error('English UI did not render');passed.push('actual Android WebView switches to English');
 if(JSON.stringify({units:original.units,location:original.location,plans:original.plans})!==JSON.stringify({units:english.units,location:english.location,plans:english.plans}))throw Error('Language changed units/place/plans');passed.push('language preserves actual units, location and plans');
 await fs.writeFile('acceptance/native-english.png',execFileSync(adbPath(),['-s','emulator-5556','exec-out','screencap','-p']));
 await click('简体中文');await pause(400);
 if(!(await evaluate("document.documentElement.lang.startsWith('zh') && document.body.innerText.includes('设置')")))throw Error('Chinese UI did not return');passed.push('actual Android WebView returns to Chinese');
 await fs.writeFile('acceptance/native-bilingual.json',JSON.stringify({passed:passed.length,checks:passed,scope:'Actual final APK WebView language controls; no physical-device performance claim'},null,2));console.log(JSON.stringify({passed:passed.length,checks:passed}));
}finally {socket.close();}
