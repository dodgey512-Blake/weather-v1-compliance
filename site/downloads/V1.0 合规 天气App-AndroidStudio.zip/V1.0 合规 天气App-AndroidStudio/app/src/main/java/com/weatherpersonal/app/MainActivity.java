package com.weatherpersonal.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.webkit.GeolocationPermissions;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import androidx.webkit.JavaScriptReplyProxy;
import androidx.webkit.WebMessageCompat;
import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;
import org.json.JSONObject;
import java.io.ByteArrayInputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;

/** Offline-first hybrid host. No remote document is loaded into the native bridge origin. */
public final class MainActivity extends Activity {
    public static final String ORIGIN = "https://appassets.androidplatform.net";
    public static final String START = ORIGIN + NativePolicy.PATH;
    private static final int LOCATION_PERMISSION = 101;
    private static final int NOTIFICATION_PERMISSION = 102;
    private static final int SAVE_DOCUMENT = 103;
    private static final int PICK_DOCUMENT = 104;
    private static final String CHANNEL = "weather_updates_compliance_v1";
        private WebView web;
    private String language;
    private boolean requestInProgress;
    private byte[] pendingFile;
    private String pendingName;
    private ValueCallback<Uri[]> filePicker;
    private CancellationSignal locationCancellation;
    private LocationListener legacyLocationListener;
    private int locationGeneration;
    private boolean locationDisclosureShowing;
    private AlertDialog locationDisclosure;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private static final String BRIDGE = "(()=>{if(window.WeatherNative)return;const send=(method,args={})=>window.WeatherBridge.postMessage(JSON.stringify({method,...args}));Object.defineProperty(window,'WeatherNative',{value:Object.freeze({isNative:true,version:'1.0.0-compliance',requestNotifications:()=>send('requestNotifications'),notify:(title,body)=>send('notify',{title,body}),requestLocation:()=>send('requestLocation'),saveFile:(name,mime,base64)=>send('saveFile',{name,mime,base64}),setLanguage:(language)=>send('setLanguage',{language}),clearLocalData:()=>send('clearLocalData'),getStatus:()=>send('getStatus'),disableNotifications:()=>send('disableNotifications')}),writable:false});window.dispatchEvent(new CustomEvent('weather-native',{detail:{type:'ready',version:'1.0.0-compliance'}}));})();";

    // React needs JavaScript; only the bundled, frame-isolated origin receives the bridge.
    @SuppressLint("SetJavaScriptEnabled") @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        language = getPreferences(MODE_PRIVATE).getString("language", "zh-CN");
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(9,16,25));
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
            getWindow().getDecorView().setSystemUiVisibility(0);
        } else {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        }
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            if (Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                android.graphics.Insets ime = insets.getInsets(WindowInsets.Type.ime());
                v.setPadding(bars.left,bars.top,bars.right,Math.max(bars.bottom,ime.bottom));
            } else v.setPadding(insets.getSystemWindowInsetLeft(),insets.getSystemWindowInsetTop(),insets.getSystemWindowInsetRight(),insets.getSystemWindowInsetBottom());
            return insets;
        });
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(9,16,25));
        root.addView(web,new FrameLayout.LayoutParams(-1,-1));
        setContentView(root);
        web.setId(View.generateViewId());
        web.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_YES);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setUserAgentString(settings.getUserAgentString() + " WeatherCompliance/1.0");
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setSupportMultipleWindows(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setGeolocationEnabled(false);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setTextZoom(Math.max(100,Math.round(getResources().getConfiguration().fontScale*100)));
        WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG);
        WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
            .addPathHandler("/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri url = request.getUrl();
                if (trusted(url)) {
                    Uri assetUri = url;
                    if (url.getPath() != null && url.getPath().endsWith("/")) assetUri = url.buildUpon().path(url.getPath()+"index.html").build();
                    WebResourceResponse response = loader.shouldInterceptRequest(assetUri);
                    if (response == null) return denied(404,"Asset not found");
                    Map<String,String> headers = new HashMap<>();
                    headers.put("Content-Security-Policy", "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; font-src 'self'; connect-src 'self' https://api.weather.gov; frame-src 'none'; object-src 'none'; base-uri 'self'; form-action 'none'");
                    headers.put("X-Content-Type-Options","nosniff");
                    response.setResponseHeaders(headers);
                    return response;
                }
                if (NativePolicy.apiResource(url.toString()) && !request.isForMainFrame()) return null;
                return denied(403,"External resources are not permitted");
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri=request.getUrl();
                if(trusted(uri) && (uri.getPath().contains("/downloads/") || uri.getPath().contains("/vis-2/"))) { openExternal(uri.buildUpon().authority("dodgey512-blake.github.io").build()); return true; }
                if (trusted(uri) && request.isForMainFrame()) return false;
                if(request.isForMainFrame() && ("https".equals(uri.getScheme()) || "mailto".equals(uri.getScheme()))) openExternal(uri);
                return true;
            }
            @Override public void onPageFinished(WebView view, String url) {
                if(trusted(Uri.parse(url))) {
                    if(WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) {
                        view.evaluateJavascript(BRIDGE,null);
                        emit(json("type","ready","version","1.0.0-compliance","language",language));
                        emitStatus();
                    }
                }
            }
            @Override public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                ((FrameLayout)view.getParent()).removeView(view);
                view.destroy();web=null;
                new AlertDialog.Builder(MainActivity.this).setTitle(text("重新打开天气","Reopen Weather"))
                    .setMessage(text("页面暂时中断，已保存的计划仍保留在此设备。","The page stopped. Saved plans remain on this device."))
                    .setPositiveButton(text("重新打开","Reopen"),(dialog,which)->recreate()).setNegativeButton(text("退出","Close"),(dialog,which)->finish()).setCancelable(false).show();
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                // The facade is the single consent-gated location path. Direct WebView geolocation is disabled.
                callback.invoke(origin, false, false);
            }
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if(filePicker!=null) filePicker.onReceiveValue(null);
                filePicker=callback;
                try { startActivityForResult(params.createIntent(),PICK_DOCUMENT); return true; }
                catch(Exception exception) { filePicker.onReceiveValue(null);filePicker=null;return false; }
            }
        });
        if(WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) {
            WebViewCompat.addWebMessageListener(web,"WeatherBridge",Collections.singleton(ORIGIN),(view,message,sourceOrigin,isMainFrame,replyProxy)->{
                if(!isMainFrame || !ORIGIN.equals(sourceOrigin.toString()) || !trusted(Uri.parse(view.getUrl()==null?"":view.getUrl()))) return;
                String data=message.getData();
                if(data==null || data.length()>NativePolicy.MAX_ENCODED_EXPORT+1024) return;
                try { handle(new JSONObject(data)); } catch(Exception exception) { error("bridge",text("操作未完成，请重试","The action could not be completed. Try again.")); }
            });
            if(WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) WebViewCompat.addDocumentStartJavaScript(web,BRIDGE,Collections.singleton(ORIGIN));
        }
        if(Build.VERSION.SDK_INT >= 33) getOnBackInvokedDispatcher().registerOnBackInvokedCallback(0,this::goBack);
        if(savedInstanceState==null || web.restoreState(savedInstanceState)==null) web.loadUrl(START);
        root.requestApplyInsets();
    }

    private boolean trusted(Uri uri) { return uri != null && NativePolicy.trustedDocument(uri.toString()); }
    private WebResourceResponse denied(int code,String message) { return new WebResourceResponse("text/plain","utf-8",code,message,Collections.emptyMap(),new ByteArrayInputStream(message.getBytes(StandardCharsets.UTF_8))); }
    private void openExternal(Uri uri) { try { startActivity(new Intent(Intent.ACTION_VIEW,uri)); } catch(Exception exception) { error("link",text("没有可用于打开链接的应用","No app can open this link.")); } }
    private String text(String zh,String en) { return "en".equals(language)?en:zh; }
    private JSONObject json(Object... values) { JSONObject value=new JSONObject(); try{for(int i=0;i<values.length;i+=2)value.put(String.valueOf(values[i]),values[i+1]);}catch(Exception ignored){}return value; }
    private void emit(JSONObject value) { if(web==null)return;handler.post(()->{if(trusted(Uri.parse(web.getUrl()==null?"":web.getUrl())))web.evaluateJavascript("window.dispatchEvent(new CustomEvent('weather-native',{detail:"+value+"}));",null);}); }
    private void error(String operation,String message) { emit(json("type","error","operation",operation,"message",message)); }
    private void handle(JSONObject message) {
        switch(message.optString("method")) {
            case "requestNotifications": requestNotifications(); break;
            case "notify": showNotification(message.optString("title"),message.optString("body")); break;
            case "requestLocation": confirmLocationUse(); break;
            case "getStatus": emitStatus(); break;
            case "clearLocalData": clearLocalData(); break;
            case "disableNotifications": disableNotifications(); break;
            case "saveFile": saveFile(message.optString("name"),message.optString("mime"),message.optString("base64"));break;
            case "setLanguage":
                language="en".equals(message.optString("language"))?"en":"zh-CN";
                getPreferences(MODE_PRIVATE).edit().putString("language",language).apply();
                emit(json("type","language","language",language));break;
            default: error("bridge",text("不支持的操作","Unsupported action"));
        }
    }
    private void requestNotifications() {
        getPreferences(MODE_PRIVATE).edit().putBoolean("notificationsWanted", true).apply();
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},NOTIFICATION_PERMISSION);
        else emitNotificationPermission();
    }
    private void showNotification(String title,String body) {
        NotificationManager manager=getSystemService(NotificationManager.class);
        if(!getPreferences(MODE_PRIVATE).getBoolean("notificationsWanted", false) || (Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)||!manager.areNotificationsEnabled()) { error("notify",text("请在设置中允许通知","Allow notifications in Settings first."));return; }
        if(title.trim().isEmpty()||body.trim().isEmpty())return;
        manager.createNotificationChannel(new NotificationChannel(CHANNEL,text("天气更新","Weather updates"),NotificationManager.IMPORTANCE_DEFAULT));
        if (!notificationsEnabled()) { emitStatus(); error("notify",text("通知通道已关闭，请在系统设置中更改","The notification channel is off. Change it in system settings."));return; }
        PendingIntent intent=PendingIntent.getActivity(this,0,new Intent(this,MainActivity.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification notification=new Notification.Builder(this,CHANNEL).setSmallIcon(R.drawable.ic_weather_notification).setContentTitle(title.substring(0,Math.min(title.length(),100))).setContentText(body.substring(0,Math.min(body.length(),300))).setStyle(new Notification.BigTextStyle().bigText(body.substring(0,Math.min(body.length(),1000)))).setContentIntent(intent).setVisibility(Notification.VISIBILITY_PRIVATE).setAutoCancel(true).build();
        manager.notify(1001,notification);emit(json("type","notification","submitted",true));
    }
    private boolean hasLocationPermission() { return checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED; }
    private void requestLocationPermission() { requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION},LOCATION_PERMISSION); }
    private void confirmLocationUse() {
        if (locationDisclosureShowing || requestInProgress) return;
        locationDisclosureShowing = true;
        locationDisclosure = new AlertDialog.Builder(this)
            .setTitle(text("使用大致位置", "Use approximate location"))
            .setMessage(text("仅在本次操作获取大致位置，坐标先取至小数点后两位，用于NWS天气和预警查询。这些服务会接收该位置和网络请求信息。也可以取消并手动搜索城市。", "For this request, use approximate location rounded to two decimal places for NWS weather and alerts. These services receive that location and request information. You can cancel and search for a city manually."))
            .setPositiveButton(text("同意并继续", "Agree and continue"), (dialog, which) -> {
                if (hasLocationPermission()) {
                    readLocation();
                } else requestLocationPermission();
            })
            .setNegativeButton(text("手动选城市", "Choose city manually"), (dialog, which) -> declineLocation())
            .setOnCancelListener(dialog -> declineLocation())
            .setOnDismissListener(dialog -> { locationDisclosureShowing = false; locationDisclosure = null; })
            .create();
        locationDisclosure.show();
    }
    private void declineLocation() {
        error("location", text("已取消定位，可以手动搜索城市", "Location cancelled. Search for a city manually."));
    }
    private boolean notificationsEnabled() {
        NotificationManager manager = getSystemService(NotificationManager.class);
        NotificationChannel channel = manager.getNotificationChannel(CHANNEL);
        return (Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED)
            && manager.areNotificationsEnabled() && (channel == null || channel.getImportance() != NotificationManager.IMPORTANCE_NONE);
    }
    private void emitStatus() {
        emit(json("type", "status", "notifications", notificationsEnabled(), "locationGranted", hasLocationPermission(), "approximateOnly", true));
    }
    private void emitNotificationPermission() {
        boolean granted = notificationsEnabled();
        getPreferences(MODE_PRIVATE).edit().putBoolean("notificationsWanted", granted).apply();
        emit(json("type", "notifications", "granted", granted));
    }
    private void disableNotifications() {
        getPreferences(MODE_PRIVATE).edit().putBoolean("notificationsWanted", false).apply();
        getSystemService(NotificationManager.class).cancelAll();
        emit(json("type", "notificationPreference", "enabled", false));
    }
    private void cancelLocation() {
        locationGeneration++;
        requestInProgress = false;
        if (locationCancellation != null) { locationCancellation.cancel(); locationCancellation = null; }
        if (legacyLocationListener != null) {
            getSystemService(LocationManager.class).removeUpdates(legacyLocationListener);
            legacyLocationListener = null;
        }
    }
    @SuppressWarnings("MissingPermission") private void readLocation() {
        if (requestInProgress || !hasLocationPermission()) return;
        LocationManager manager = getSystemService(LocationManager.class);
        if (!manager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
            error("location", text("大致定位不可用，请手动搜索城市", "Approximate location is unavailable. Search for a city.")); return;
        }
        requestInProgress = true;
        int generation = ++locationGeneration;
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                locationCancellation = new CancellationSignal();
                manager.getCurrentLocation(LocationManager.NETWORK_PROVIDER, locationCancellation, getMainExecutor(), location -> {
                    if (generation != locationGeneration) return;
                    cancelLocation();
                    if (location != null) emitLocation(location); else error("location", text("未能获取位置，请手动搜索", "Location is unavailable. Search for a place."));
                });
            } else {
                legacyLocationListener = new LocationListener() {
                    public void onLocationChanged(Location location) { if (generation == locationGeneration) { cancelLocation(); emitLocation(location); } }
                    public void onStatusChanged(String provider, int status, Bundle extras) { }
                    public void onProviderEnabled(String provider) { }
                    public void onProviderDisabled(String provider) { }
                };
                manager.requestSingleUpdate(LocationManager.NETWORK_PROVIDER, legacyLocationListener, Looper.getMainLooper());
            }
            handler.postDelayed(() -> { if (generation == locationGeneration && requestInProgress) { cancelLocation(); error("location", text("定位超时，请手动搜索", "Location timed out. Search for a place.")); } }, 20000);
        } catch (SecurityException exception) { cancelLocation(); emitStatus(); error("location", text("定位权限已改变，请手动搜索", "Location permission changed. Search for a place.")); }
    }
    private void emitLocation(Location location) {
        emit(json("type", "location", "latitude", NativePolicy.approximateCoordinate(location.getLatitude()), "longitude", NativePolicy.approximateCoordinate(location.getLongitude()), "accuracy", Math.max(1500, location.getAccuracy()), "approximate", true));
    }
    private void clearLocalData() {
        cancelLocation();
        if (locationDisclosure != null) locationDisclosure.cancel();
        if (!getPreferences(MODE_PRIVATE).edit().clear().commit()) {
            error("clearLocalData", text("本机偏好清除未完成，请重试", "Native preference clearing did not complete. Try again.")); return;
        }
        language = "zh-CN";
        getSystemService(NotificationManager.class).cancelAll();
        pendingFile = null; pendingName = null;
        GeolocationPermissions.getInstance().clearAll();
        if (web != null) { web.clearCache(true); web.clearHistory(); }
        emit(json("type", "localDataCleared", "cleared", true));
    }
    private void saveFile(String name,String mime,String base64) {
        if(pendingFile!=null){error("saveFile",text("请先完成当前保存","Finish saving the current file first."));return;}
        if(base64.length()>NativePolicy.MAX_ENCODED_EXPORT){error("saveFile",text("文件过大","File is too large."));return;}
        try {
            String safeName = NativePolicy.exportName(name, mime);
            byte[] decoded = Base64.decode(base64, Base64.DEFAULT);
            if (decoded.length > NativePolicy.MAX_EXPORT_BYTES) { error("saveFile", text("文件过大", "File is too large.")); return; }
            pendingFile = decoded;
            pendingName = safeName;
            Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType(mime).putExtra(Intent.EXTRA_TITLE,pendingName);
            startActivityForResult(intent,SAVE_DOCUMENT);
        }catch(Exception exception){pendingFile=null;error("saveFile",text("无法打开文件保存窗口","Could not open the file picker."));}
    }
    @Override public void onRequestPermissionsResult(int code,String[] permissions,int[] results) {
        super.onRequestPermissionsResult(code,permissions,results);
        if(code==NOTIFICATION_PERMISSION) emitNotificationPermission();
        if(code==LOCATION_PERMISSION){boolean allowed=hasLocationPermission();if(allowed)readLocation();else error("location",text("定位权限未开启，可以手动搜索地点","Location permission is off. Search for a place instead."));}
    }
    @Override protected void onActivityResult(int code,int resultCode,Intent data) {
        super.onActivityResult(code,resultCode,data);
        if(code==PICK_DOCUMENT && filePicker!=null){filePicker.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode,data));filePicker=null;}
        if(code==SAVE_DOCUMENT && pendingFile!=null){
            if(resultCode==RESULT_OK && data!=null && data.getData()!=null){try(OutputStream stream=getContentResolver().openOutputStream(data.getData())){if(stream==null)throw new IllegalStateException();stream.write(pendingFile);emit(json("type","saved","name",pendingName));}catch(Exception exception){error("saveFile",text("保存失败，请重试","Save failed. Try again."));}}
            else emit(json("type","saveCancelled","name",pendingName));
            pendingFile=null;pendingName=null;
        }
    }
    private void goBack(){web.evaluateJavascript("typeof window.__weatherBack==='function' ? Boolean(window.__weatherBack()) : false", result->{if(!"true".equals(result)){if(web.canGoBack())web.goBack();else finish();}});}
    // API 33+ uses the registered OnBackInvokedCallback above. This override is for API 26–32.
    @SuppressLint("GestureBackNavigation") @Override public void onBackPressed(){goBack();}
    @Override protected void onSaveInstanceState(Bundle bundle){if(web!=null)web.saveState(bundle);super.onSaveInstanceState(bundle);}
    @Override protected void onResume(){super.onResume();if(web!=null){web.onResume();web.evaluateJavascript("window.dispatchEvent(new Event('weather-resume'))",null);emitStatus();}}
    @Override protected void onPause(){if(requestInProgress){cancelLocation();error("location",text("定位已暂停，可以手动搜索城市","Location paused. Search for a city manually."));}if(web!=null)web.onPause();super.onPause();}
    @Override protected void onDestroy(){cancelLocation();if(locationDisclosure!=null)locationDisclosure.dismiss();if(web!=null){web.stopLoading();web.destroy();web=null;}super.onDestroy();}
    WebView webViewForTest(){return web;}
}
