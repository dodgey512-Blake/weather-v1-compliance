package com.weatherpersonal.app;

import java.net.URI;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/** Boundary rules shared by the running host and the plain-Java regression checks. */
final class NativePolicy {
    static final String PATH = "/weather-v1-compliance/";
    static final int MAX_EXPORT_BYTES = 2 * 1024 * 1024;
    static final int MAX_ENCODED_EXPORT = 2_800_000;
    private static final Set<String> API_HOSTS = new HashSet<>(Arrays.asList(
        "api.weather.gov"));

    static boolean trustedDocument(String value) {
        try {
            URI uri = new URI(value);
            String rawPath = uri.getRawPath();
            return "https".equals(uri.getScheme()) && "appassets.androidplatform.net".equals(uri.getHost())
                && uri.getRawUserInfo() == null && (uri.getPort() == -1 || uri.getPort() == 443)
                && rawPath != null && rawPath.startsWith(PATH) && !rawPath.contains("%")
                && uri.normalize().getRawPath().equals(rawPath);
        } catch (Exception invalid) { return false; }
    }

    static boolean apiResource(String value) {
        try {
            URI uri = new URI(value);
            return "https".equals(uri.getScheme()) && API_HOSTS.contains(uri.getHost())
                && uri.getRawUserInfo() == null && (uri.getPort() == -1 || uri.getPort() == 443);
        } catch (Exception invalid) { return false; }
    }

    static String exportName(String name, String mime) {
        String extension;
        switch (mime) {
            case "application/json": extension = ".json"; break;
            case "text/calendar": extension = ".ics"; break;
            case "text/plain": extension = ".txt"; break;
            default: throw new IllegalArgumentException("Unsupported export type");
        }
        String safe = name.replaceAll("[^\\p{L}\\p{N}._ -]", "_").trim();
        while (safe.startsWith(".")) safe = safe.substring(1);
        if (safe.length() > 100) safe = safe.substring(0, 100);
        if (safe.isEmpty()) safe = "weather-export";
        if (!safe.toLowerCase(java.util.Locale.ROOT).endsWith(extension)) safe += extension;
        return safe;
    }

    static double approximateCoordinate(double value) {
        return Math.round(value * 100.0) / 100.0;
    }
}
