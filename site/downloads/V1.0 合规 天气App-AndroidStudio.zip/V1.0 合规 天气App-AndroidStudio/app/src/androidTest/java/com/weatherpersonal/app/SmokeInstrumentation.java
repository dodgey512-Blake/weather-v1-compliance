package com.weatherpersonal.app;

import android.Manifest;
import android.app.AlertDialog;
import android.app.Instrumentation;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/** Exercises the actual packaged WebView and consent/native state on the isolated test app. */
public final class SmokeInstrumentation extends Instrumentation {
    private MainActivity activity;
    private int count;
    private String evaluate(String script) throws Exception {
        CountDownLatch latch = new CountDownLatch(1);
        String[] value = {"null"};
        runOnMainSync(() -> activity.webViewForTest().evaluateJavascript(script, result -> { value[0] = result; latch.countDown(); }));
        if (!latch.await(15, TimeUnit.SECONDS)) throw new AssertionError("JavaScript response timed out");
        return value[0];
    }
    private void require(String name, boolean value) {
        if (!value) throw new AssertionError(name);
        count++;
        Bundle status = new Bundle(); status.putString("stream", "PASS " + name + "\n"); sendStatus(0, status);
    }
    private void check(String name, String expression) throws Exception { require(name, "true".equals(evaluate(expression))); }
    private AlertDialog consentDialog() throws Exception {
        Field field = MainActivity.class.getDeclaredField("locationDisclosure"); field.setAccessible(true);
        return (AlertDialog) field.get(activity);
    }
    @Override public void onCreate(Bundle args) { super.onCreate(args); start(); }
    @Override public void onStart() {
        Bundle result = new Bundle();
        try {
            activity = (MainActivity) startActivitySync(new Intent(getTargetContext(), MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            long deadline = System.currentTimeMillis() + 60000;
            boolean ready = false;
            while (System.currentTimeMillis() < deadline && !ready) {
                try { ready = "true".equals(evaluate("document.readyState==='complete' && !!window.WeatherNative && document.body.innerText.length>30")); }
                catch (AssertionError initializing) { }
                if (!ready) Thread.sleep(250);
            }
            require("packaged application starts", ready);
            check("trusted HTTPS origin", "location.origin==='https://appassets.androidplatform.net'");
            check("independent bundled path", "location.pathname.startsWith('/weather-v1-compliance/')");
            check("packaged UI rendered", "document.body.innerText.length>30 && !document.body.innerText.includes('ERR_') && document.querySelectorAll('button').length>0");
            check("consent native facade", "typeof WeatherNative.requestLocation==='function' && typeof WeatherNative.getStatus==='function' && typeof WeatherNative.clearLocalData==='function' && typeof WeatherNative.disableNotifications==='function'");
            check("immutable facade", "Object.isFrozen(WeatherNative)");
            check("Chinese default", "document.documentElement.lang.startsWith('zh')");
            check("local runtime loaded", "performance.getEntriesByType('resource').some(x=>x.initiatorType==='script' && x.name.startsWith(location.origin))");
            check("identifiable NWS user agent", "navigator.userAgent.includes('WeatherCompliance/1.0')");
            check("independent local storage works", "(()=>{localStorage.setItem('__native_smoke','ok');const ok=localStorage.getItem('__native_smoke')==='ok';localStorage.removeItem('__native_smoke');return ok})()");
            PackageInfo info = getTargetContext().getPackageManager().getPackageInfo(getTargetContext().getPackageName(), PackageManager.GET_PERMISSIONS);
            require("coarse permission declared", Arrays.asList(info.requestedPermissions).contains(Manifest.permission.ACCESS_COARSE_LOCATION));
            require("fine location omitted", !Arrays.asList(info.requestedPermissions).contains(Manifest.permission.ACCESS_FINE_LOCATION));
            require("background location omitted", !Arrays.asList(info.requestedPermissions).contains(Manifest.permission.ACCESS_BACKGROUND_LOCATION));
            evaluate("window.__nativeEvents=[];window.addEventListener('weather-native',e=>__nativeEvents.push(e.detail));WeatherNative.getStatus()");
            Thread.sleep(250);
            check("status is asynchronous and accurate", "__nativeEvents.some(e=>e.type==='status' && typeof e.notifications==='boolean' && e.approximateOnly===true)");
            evaluate("WeatherNative.requestLocation()"); Thread.sleep(300);
            require("native purpose disclosure precedes permission", consentDialog() != null && consentDialog().isShowing());
            require("location not granted before consent", activity.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED);
            runOnMainSync(() -> { try { consentDialog().getButton(AlertDialog.BUTTON_NEGATIVE).performClick(); } catch (Exception e) { throw new RuntimeException(e); } });
            Thread.sleep(250);
            check("declined location has manual fallback feedback", "__nativeEvents.some(e=>e.type==='error' && e.operation==='location')");
            require("declined location does not grant permission", activity.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED);
            evaluate("__nativeEvents=[];WeatherNative.notify('weather test','request denied')"); Thread.sleep(250);
            check("notification without consent reports failure", "__nativeEvents.some(e=>e.type==='error' && e.operation==='notify') && !__nativeEvents.some(e=>e.type==='notification' && (e.delivered || e.submitted))");
            NotificationManager manager = activity.getSystemService(NotificationManager.class);
            runOnMainSync(() -> manager.createNotificationChannel(new NotificationChannel("weather_updates_compliance_v1", "Test channel", NotificationManager.IMPORTANCE_NONE)));
            evaluate("__nativeEvents=[];WeatherNative.getStatus()"); Thread.sleep(250);
            check("blocked channel reported unavailable", "__nativeEvents.some(e=>e.type==='status' && e.notifications===false)");
            evaluate("__nativeEvents=[];WeatherNative.saveFile('page.html','text/html',btoa('<html>test</html>'))"); Thread.sleep(250);
            check("active export MIME rejected", "__nativeEvents.some(e=>e.type==='error' && e.operation==='saveFile') && !__nativeEvents.some(e=>e.type==='saved')");
            evaluate("__nativeEvents=[];WeatherNative.disableNotifications()"); Thread.sleep(200);
            check("in-app notification disable acknowledged", "__nativeEvents.some(e=>e.type==='notificationPreference' && e.enabled===false)");
            require("disabled notification preference persisted", !activity.getPreferences(0).getBoolean("notificationsWanted", true));
            require("native notification clear completed", manager.getActiveNotifications().length == 0);
            evaluate("__nativeEvents=[];WeatherNative.setLanguage('en')"); Thread.sleep(200);
            require("native language preference saved", "en".equals(activity.getPreferences(0).getString("language", "")));
            evaluate("WeatherNative.clearLocalData()"); Thread.sleep(300);
            check("native deletion acknowledged after action", "__nativeEvents.some(e=>e.type==='localDataCleared' && e.cleared===true)");
            require("native preferences actually erased", activity.getPreferences(0).getAll().isEmpty());
            check("clearing native state keeps page operable", "!!window.WeatherNative && document.querySelectorAll('button').length>0");
            result.putString("stream", "Weather native compliance: " + count + " checks passed.\n");
            result.putInt("checks", count); finish(-1, result);
        } catch (Throwable error) { result.putString("stream", "FAIL " + error + "\n"); finish(0, result); }
    }
}
