package com.weatherpersonal.app;

public final class NativePolicyCheck {
    private static int checks;
    private static void require(String name, boolean value) {
        if (!value) throw new AssertionError(name);
        checks++;
    }
    public static void main(String[] args) {
        String origin = "https://appassets.androidplatform.net";
        require("current bundled root", NativePolicy.trustedDocument(origin + NativePolicy.PATH));
        require("current bundled runtime", NativePolicy.trustedDocument(origin + NativePolicy.PATH + "_next/static/app.js"));
        require("HTTPS default port", NativePolicy.trustedDocument("https://appassets.androidplatform.net:443" + NativePolicy.PATH));
        require("old edition rejected", !NativePolicy.trustedDocument(origin + "/weather-v1/index.html"));
        require("alternate port rejected", !NativePolicy.trustedDocument("https://appassets.androidplatform.net:444" + NativePolicy.PATH));
        require("user info rejected", !NativePolicy.trustedDocument("https://someone@appassets.androidplatform.net" + NativePolicy.PATH));
        require("host suffix rejected", !NativePolicy.trustedDocument("https://appassets.androidplatform.net.evil.invalid" + NativePolicy.PATH));
        require("cleartext rejected", !NativePolicy.trustedDocument("http://appassets.androidplatform.net" + NativePolicy.PATH));
        require("literal traversal rejected", !NativePolicy.trustedDocument(origin + NativePolicy.PATH + "../private"));
        require("encoded traversal rejected", !NativePolicy.trustedDocument(origin + NativePolicy.PATH + "%2e%2e/private"));
        require("unrelated native path rejected", !NativePolicy.trustedDocument(origin + "/private/file"));
        require("NWS API accepted", NativePolicy.apiResource("https://api.weather.gov/points/30.26,-97.74"));
        require("unlicensed optional API blocked", !NativePolicy.apiResource("https://air-quality-api.open-meteo.com/v1/air-quality"));
        require("API user info rejected", !NativePolicy.apiResource("https://x@api.weather.gov/points/30,-97"));
        require("API port rejected", !NativePolicy.apiResource("https://api.weather.gov:444/points/30,-97"));
        require("API cleartext rejected", !NativePolicy.apiResource("http://api.weather.gov/points/30,-97"));
        require("JSON extension preserved", NativePolicy.exportName("weather.json", "application/json").equals("weather.json"));
        require("wrong extension cannot become HTML", NativePolicy.exportName("weather.html", "application/json").endsWith(".json"));
        require("calendar export suffix", NativePolicy.exportName("plan", "text/calendar").equals("plan.ics"));
        require("path separators removed", !NativePolicy.exportName("../../private/file", "text/plain").contains("/"));
        require("empty export name", NativePolicy.exportName("", "application/json").equals("weather-export.json"));
        boolean rejected = false;
        try { NativePolicy.exportName("evil.html", "text/html"); } catch (IllegalArgumentException expected) { rejected = true; }
        require("active MIME rejected", rejected);
        require("positive coordinate minimized", NativePolicy.approximateCoordinate(30.267153) == 30.27);
        require("negative coordinate minimized", NativePolicy.approximateCoordinate(-97.743057) == -97.74);
        require("zero coordinate preserved", NativePolicy.approximateCoordinate(0) == 0);
        System.out.println("{\"passed\":" + checks + ",\"scope\":\"plain-Java URI/export/coordinate policy boundaries\"}");
    }
}
