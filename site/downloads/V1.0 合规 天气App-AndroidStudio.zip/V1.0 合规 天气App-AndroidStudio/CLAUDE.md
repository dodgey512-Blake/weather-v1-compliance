# V1.0 合规 天气App · Android

本目录为2026年11月7日授权创建的独立合规宿主副本，旧 `Android/WeatherV1` 不得覆盖。

1. `applicationId` 为 `com.weatherpersonal.app.compliance`，Java namespace 保持 `com.weatherpersonal.app`，可与旧版并装。原生入口为 `https://appassets.androidplatform.net/weather-v1-compliance/`。
2. Web源和数据规则由兄弟 `../web/` 维护，本宿主通过 `scripts/package-web.mjs` 打包最终 `../web/out`。未最终打包不得交付旧资产。
3. 仅声明COARSE_LOCATION，用户在原生用途及NWS接收者说明中同意后才请求系统授权与本次大致定位。坐标到Web前保留2位小数，不后台跟踪。WebView直接geolocation关闭，统一使用原生facade。
4. WebView只信任本版HTTPS来源、默认端口与规范路径。网络接口限NWS。User-Agent追加WeatherCompliance/1.0，正式服务端与运营联系仍需后续提供。
5. `getStatus()`异步报告permission/channel状态；`requestNotifications()`按用户操作申请，`disableNotifications()`关闭本机App偏好并取消通知；通知提交只标submitted，不能宣称已被看见。
6. `clearLocalData()`取消定位和通知、清本版本原生偏好/地理授权/临时文件及WebView缓存。Web localStorage由React当前namespace负责清除，跨端返回事件为localDataCleared。
7. JSON、ICS、TXT导出只使用系统SAF，白名单MIME、扩展名和2MiB上限，不申请广泛存储权限。用户取消不显示保存成功。
8. 输出APK与AndroidStudio ZIP到 `../dist`，排除本地SDK路径、镜像、构建缓存、验收录屏和凭证。原生实际测试与来源/导出plain-Java测试分别记载。
9. 交付使用debug签名。物理设备、TalkBack、性能、正式商店服务及签名/审核待办保持明确。
