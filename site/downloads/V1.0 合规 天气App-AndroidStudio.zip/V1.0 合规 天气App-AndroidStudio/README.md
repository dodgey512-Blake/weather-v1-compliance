# V1.0 合规 天气App · Android Studio

1. Android Studio打开此目录，使用JDK17或更高版本，安装Android SDK37，运行app。Gradle9.3.1、AGP9.1.1、AndroidX WebKit1.18.0，minSdk26、targetSdk37。
2. 源码包内已经包含最终Web资产，可以直接执行 `./gradlew :app:assembleDebug`。本机SDK位置由Android Studio配置，不在交付源码中携带。
3. 完整交付包中，前端源位于兄弟web目录。前端静态构建后运行 `sh scripts/build-and-export.sh ../web/out`，得到兄弟dist中的APK与源码ZIP。独立Android源码包也可仅使用已随包资产构建。
4. basePath为 `/weather-v1-compliance`，WebView可信本地HTTPS来源使用同一路径。Next的 `_next` 目录必须保留，AAPT排除规则不能丢弃它。
5. 应用身份为 `com.weatherpersonal.app.compliance`，与旧版并装。测试包入口类为 `com.weatherpersonal.app.SmokeInstrumentation`，Java namespace没有改为applicationId。
6. `WeatherNative`以受限WebMessage异步桥提供requestLocation、requestNotifications、notify、saveFile、setLanguage、getStatus、disableNotifications和clearLocalData。所有返回通过weather-native事件，getStatus返回type=status，清除完成返回localDataCleared。
7. 定位只请求大致位置，每次获取前说明NWS接收者和用途，允许改用手动城市。原生坐标先取两位小数，未启用后台定位。WebView直接定位API关闭。
8. 通知受系统权限、channel和应用开关共同控制，只在应用运行并获得新天气时产生。提交给系统不保证用户已经收到或读到。本宿主不提供后台持续天气监测。
9. 系统保存只允许JSON、ICS和TXT，名称和类型受限，最大2MiB。清除本机数据不删除用户已经保存到外部的文件，也不会自行撤销系统授权。
10. 运行 `python3 scripts/verify-native.py --fresh --serial emulator-5556` 可在本版独立模拟器应用上验证实际操作。fresh只清本版测试数据。25项plain-Java政策边界测试与模拟器结果分别保存。
11. APK使用测试签名，正式发布需要签名/AAB、商店控制台与权限说明、真实数据服务合同及物理设备/无障碍/性能验收。

官方依据 [受限原生桥](https://developer.android.com/privacy-and-security/risks/insecure-webview-native-bridges)、[本地内容](https://developer.android.com/develop/ui/views/layout/webapps/load-local-content)、[位置权限](https://developer.android.com/develop/sensors-and-location/location/permissions/runtime)。
