import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
const root=process.cwd(),out=path.join(root,'out'),base='/weather-v1-compliance/';
async function walk(dir){return(await Promise.all((await fs.readdir(dir,{withFileTypes:true})).map(e=>e.isDirectory()?walk(path.join(dir,e.name)):path.join(dir,e.name)))).flat();}
const index=await fs.readFile(path.join(out,'index.html'));const cache='weather-v1-compliance-'+crypto.createHash('sha256').update(index).digest('hex').slice(0,12);
const assets=(await walk(path.join(out,'_next'))).filter(f=>/\.(js|css|woff2?)$/.test(f)).map(f=>base+path.relative(out,f).replaceAll(path.sep,'/'));
const precache=[base,base+'index.html',base+'favicon.svg',base+'manifest.webmanifest',base+'privacy.html',base+'terms.html',...assets];
const worker=`const CACHE=${JSON.stringify(cache)},BASE=${JSON.stringify(base)},ASSETS=${JSON.stringify(precache)};self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS)).then(()=>self.skipWaiting())));self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('weather-v1-compliance-')&&k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));self.addEventListener('fetch',e=>{const u=new URL(e.request.url);if(e.request.method!=='GET'||u.origin!==self.location.origin||!u.pathname.startsWith(BASE)||u.pathname.includes('/downloads/'))return;if(e.request.mode==='navigate'){const key=u.pathname===BASE?BASE+'index.html':u.pathname;e.respondWith(fetch(e.request).then(r=>{if(r.ok)caches.open(CACHE).then(c=>c.put(key,r.clone()));return r;}).catch(()=>caches.match(key).then(r=>r||Response.error())));return;}if(ASSETS.includes(u.pathname))e.respondWith(caches.match(e.request).then(c=>c||fetch(e.request)));});`;
await fs.writeFile(path.join(out,'sw.js'),worker);await fs.writeFile(path.join(out,'.nojekyll'),'');console.log(JSON.stringify({base,cache,assets:assets.length}));
