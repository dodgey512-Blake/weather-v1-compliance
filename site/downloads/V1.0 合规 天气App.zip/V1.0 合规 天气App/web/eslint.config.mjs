import { defineConfig, globalIgnores } from "eslint/config";
import nextVitals from "eslint-config-next/core-web-vitals";
import nextTs from "eslint-config-next/typescript";

const eslintConfig = defineConfig([
  ...nextVitals,
  ...nextTs,
  {
    rules: {
      // Browser persistence and the initial NWS refresh intentionally hydrate after mount.
      "react-hooks/set-state-in-effect": "off",
    },
  },
  { files: ["qa/**/*.cjs"], rules: { "@typescript-eslint/no-require-imports": "off" } },
  // Override default ignores of eslint-config-next.
  globalIgnores([
    // Default ignores of eslint-config-next:
    ".next/**",
    "out/**",
    "build/**",
    "archive/**",
    "dist/**",
    ".qa-server/**",
    "public/vis-2/downloads/**",
    "next-env.d.ts",
  ]),
]);

export default eslintConfig;
