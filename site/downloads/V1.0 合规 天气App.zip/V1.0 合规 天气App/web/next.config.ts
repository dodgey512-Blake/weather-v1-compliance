import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "export",
  turbopack: { root: process.cwd() },
  basePath: "/weather-v1-compliance",
  trailingSlash: true,
  images: { unoptimized: true },
};

export default nextConfig;
