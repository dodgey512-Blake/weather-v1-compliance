# V1.0 合规 天气App

1. 网页源码在web/，Android源码在android/，最终安装包与完整ZIP在dist/。
2. 使用独立公开路径/weather-v1-compliance/、独立Web存储及Android应用身份。原V1.0继续保留。
3. 网页在web/执行npm ci、npm run dev可开发，npm run build生成静态out。发布时再执行npm run release:site生成独立Service Worker。
4. 当前默认仅调用NWS天气与官方预警。城市搜索使用4个预置城市，也可主动授权近似定位。Open-Meteo免费地名与AQI接口已默认停用。
5. 未接入授权AQI时明确显示缺失，完整跑步评估不生成可应用改期。演练情景独立提供，不修改真实计划或指标。
6. 定位、通知和导出均由用户主动触发，JSON默认移除坐标、天气快照和自由备注。近似坐标仍按位置数据披露。
7. 当前没有账户、真实订阅/支付或广告SDK。Android为测试签名演示，正式商店、iOS、真机和商业主体等要求仍需完成。
8. 最终交付链接、测试范围和未完成项以release.json与artifacts/为准。完整产品与合规要求见《V1.0 合规 天气App.md》。
